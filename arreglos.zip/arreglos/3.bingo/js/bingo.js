/**
 * Bingo a traves de arrays
 * Autor:JR
 * 26 de abril del 2024
 */

let bingo=[];
let tabla;
let resultado;
let interno=[];


